 /* globals feather:false */
//사이드바 아이콘 js
(function () {
  'use strict'

  feather.replace()

})()
